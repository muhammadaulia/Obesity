package com.hoodini.obesity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import java.util.ArrayList;

public class AdapterHistoryView extends RecyclerView.Adapter<AdapterHistoryView.ViewHolder> {
    ArrayList<ListHistory> histories;
    private Context context;
    DatabaseReference database;
    FirebaseUser firebaseUser;


    public AdapterHistoryView(ArrayList<ListHistory> historiess, Context ctx){
        histories = historiess;
        context = ctx;
    }
    class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvTitle;
        TextView textBerat;
        TextView textTinggi;
        TextView textHasil;
        ViewHolder(View v){
            super(v);
            textTinggi = v.findViewById(R.id.tinggi);
            tvTitle = v.findViewById(R.id.tvTitle);
            textBerat = v.findViewById(R.id.berat);
            textHasil = v.findViewById(R.id.hasil);

        }
    }


    @NonNull
    @Override
    public AdapterHistoryView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_history, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterHistoryView.ViewHolder holder, final int position) {
        final String tanggal = "Tanggal Pengecekan "+histories.get(position).getDate();
        final String tinggi = "Dengan Tinggi Badan "+histories.get(position).getTinggi().toString()+" Cm";
        final String berat = "Dengan Berat Badan " +histories.get(position).getBerat().toString()+ " Kg";
        final String hasil = "Diagnosis Akhir "+ histories.get(position).getHasil();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        database = FirebaseDatabase.getInstance().getReference();
        holder.tvTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });
        holder.tvTitle.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                return true;
            }
        });
        holder.textTinggi.setText(tinggi);
        holder.tvTitle.setText(tanggal);
        holder.textBerat.setText(berat);
        holder.textHasil.setText(hasil);
    }

    @Override
    public int getItemCount() {
        return histories.size();
    }

}
