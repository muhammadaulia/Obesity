package com.hoodini.obesity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.net.URI;
import java.util.ArrayList;

public class AdapterNews extends RecyclerView.Adapter<AdapterNews.ViewHolder> {
    private ArrayList<News> mNewsData;
    private Context mContext;
    private String url;

    public AdapterNews(Context context, ArrayList<News> mNewsData) {
        this.mNewsData = mNewsData;
        this.mContext = context;
    }

    @NonNull
    @Override
    public AdapterNews.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.list_news, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterNews.ViewHolder holder, int position) {
        News currentNews = mNewsData.get(position);
        holder.bindTo(currentNews);
    }

    @Override
    public int getItemCount() {
        return mNewsData.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView mJudultext;
//        private TextView mPenjelasanText;
        private ImageView mNewsImage;

        ViewHolder(View item) {
            super(item);

            mJudultext = item.findViewById(R.id.title_news);
//            mPenjelasanText = item.findViewById(R.id.subTitle_news);
            mNewsImage = item.findViewById(R.id.image_news);
            // Set the OnClickListener to the entire view.
            item.setOnClickListener(this);
        }
        void bindTo(News currentFitur) {
            // Populate the textviews with data.
            mJudultext.setText(currentFitur.getTitle());
//            mPenjelasanText.setText(currentFitur.getInfo());

            // Load the images into the ImageView using the Glide library.
            Glide.with(mContext).load(
                    currentFitur.getImageResource()).into(mNewsImage);
        }

        @Override
        public void onClick(View view) {

            News currentNews = mNewsData.get(getAdapterPosition());
            currentNews.setPosition(getAdapterPosition());
            Log.e("onClick: ","Clicked" );

            Intent browserIntent = new Intent(Intent.ACTION_VIEW);
            Integer posisi = (int) (long) currentNews.getPosition();
            switch (posisi) {
                case 0:
                    url = "https://www.halodoc.com/kesehatan/obesitas";
                    break;
                case 1:
                    url = "https://www.alodokter.com/ini-makanan-sehat-yang-perlu-dikonsumsi-setiap-hari";
                    break;
                case 2:
                    url ="https://www.alodokter.com/beragam-manfaat-olahraga";
                    break;
                case 3:
                    url="https://www.halodoc.com/harus-tahu-ini-alasannya-obesitas-bisa-memicu-kanker";
                    break;
                default:
            }
            browserIntent.setData(Uri.parse(url));
            mContext.startActivity(browserIntent);
        }
    }

}
