package com.hoodini.obesity;

public class DataPengguna {
    String email, jkel, nama, nomor;

    public DataPengguna(){}
    public DataPengguna(String email, String nama, String jkel, String nomor){
        this.email = email;
        this.nama = nama;
        this.jkel = jkel;
        this.nomor = nomor;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getJkel() {
        return jkel;
    }

    public void setJkel(String jkel) {
        this.jkel = jkel;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNomor() {
        return nomor;
    }

    public void setNomor(String nomor) {
        this.nomor = nomor;
    }
}

