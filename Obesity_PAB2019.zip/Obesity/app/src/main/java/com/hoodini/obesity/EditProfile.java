package com.hoodini.obesity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class EditProfile extends AppCompatActivity {
    private DatabaseReference database;
    private FirebaseUser firebaseUser;
    private EditText eVNama, eVEmail, eVNomor, eVCurrpass, eVNewPass, eVRepass;
    private Button button;
    private String nama, email, nomor, currpass, jkel;
    private RadioGroup eVJkel;
    private RadioButton butJkel;
    private String editNama, editEmail, editNomor, editPass, editRepass, editCurrpas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        eVNama = findViewById(R.id.fillnama);
        eVEmail = findViewById(R.id.fillmail);
        eVNomor = findViewById(R.id.fillnomor);
        eVCurrpass = findViewById(R.id.regispass);
        eVNewPass = findViewById(R.id.fillpassbaru);
        eVRepass = findViewById(R.id.fillrepass);
        eVJkel = findViewById(R.id.radioGroup);


        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        eVEmail.setText(firebaseUser.getEmail());
        database = FirebaseDatabase.getInstance().getReference().child("User/" + firebaseUser.getUid());
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                nama = dataSnapshot.child("nama").getValue(String.class);
                nomor = dataSnapshot.child("nomor").getValue(String.class);
                jkel = dataSnapshot.child("jkel").getValue(String.class);
                currpass = dataSnapshot.child("password").getValue(String.class);


                if (jkel.equals("Laki- Laki")) {
                    butJkel = findViewById(R.id.radio_pria);
                    butJkel.setChecked(true);
                } else if (jkel.equals("Perempuan")) {
                    butJkel = findViewById(R.id.radio_wanita);
                    butJkel.setChecked(true);
                }


                eVJkel.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup, int i) {
                        butJkel = eVJkel.findViewById(i);
                        switch (i) {
                            case R.id.radio_pria:
                            case R.id.radio_wanita:
                                jkel = butJkel.getText().toString();
                                break;
                            default:
                        }
                    }
                });
                eVNama.setText(nama);
                eVNomor.setText(nomor);
                eVJkel.getCheckedRadioButtonId();
                button = findViewById(R.id.buttonSbmit);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        editNama = eVNama.getText().toString();
                        editEmail = eVEmail.getText().toString();
                        editNomor = eVNomor.getText().toString();
                        editCurrpas = eVCurrpass.getText().toString();
                        editPass = eVNewPass.getText().toString();
                        editRepass = eVRepass.getText().toString();
                        jkel = butJkel.getText().toString();


                        if (editCurrpas.isEmpty()) {
                            eVCurrpass.setError("Password Sekarang Kosong");
                            eVCurrpass.requestFocus();
                        } else if (!editCurrpas.equals(currpass)) {
                            eVCurrpass.setError("Password Kamu Salah");
                            eVCurrpass.requestFocus();
                        } else if (!editPass.equals(editRepass)) {
                            eVRepass.setError("Password Kamu Tidak Cocok");
                            eVRepass.requestFocus();
                        } else if (!editPass.isEmpty() && editPass.equals(editRepass)) {
                            firebaseUser.updatePassword(editPass).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        User user = new User(editEmail, editNama, editNomor, editPass, editRepass, jkel);
                                        database.setValue(user);
                                        Toast.makeText(EditProfile.this, "Data Berhasil Di Update", Toast.LENGTH_SHORT).show();
                                        finish();
                                    } else if (!task.isSuccessful()) {
                                        Toast.makeText(EditProfile.this, "Data Gagal Di Update", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        } else if (editPass.isEmpty() && editCurrpas.equals(currpass)) {
                            User user = new User(editEmail, editNama, editNomor, currpass, currpass, jkel);
                            database.setValue(user);
                            Toast.makeText(EditProfile.this, "Data Berhasil Di Update", Toast.LENGTH_SHORT).show();
                            finish();
                        }

                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
