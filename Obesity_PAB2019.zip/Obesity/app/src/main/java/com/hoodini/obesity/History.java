package com.hoodini.obesity;

import androidx.annotation.NonNull;

public class History {
    String date, hasil;
    int tinggi, berat;
    public History(String date, String hasil, int tinggi, int berat){
        this.date = date;
        this.hasil = hasil;
        this.tinggi = tinggi;
        this.berat = berat;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public String getHasil() {
        return hasil;
    }

    public void setHasil(String hasil) {
        this.hasil = hasil;
    }

    public int getTinggi() {
        return tinggi;
    }

    public void setTinggi(int tinggi) {
        this.tinggi = tinggi;
    }

    public int getBerat() {
        return berat;
    }

    public void setBerat(int berat) {
        this.berat = berat;
    }
    @NonNull
    @Override
    public String toString(){
        return " "+date+"\n" +
                " "+hasil+"\n" +
                " "+tinggi+"\n" +
                " "+berat;
    }
}
