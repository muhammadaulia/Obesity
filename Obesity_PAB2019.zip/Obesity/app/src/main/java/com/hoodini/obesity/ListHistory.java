package com.hoodini.obesity;

import java.io.Serializable;

public class ListHistory implements Serializable {
    String date, hasil,key;
    Long berat, tinggi;
    int position;
    public ListHistory(){

    }
    public ListHistory(String date, Long berat, Long tinggi, String hasil){
        this.date = date;
        this.berat = berat;
        this.tinggi = tinggi;
        this.hasil = hasil;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Long getBerat() {
        return berat;
    }

    public void setBerat(Long berat) {
        this.berat = berat;
    }

    public Long getTinggi() {
        return tinggi;
    }

    public void setTinggi(Long tinggi) {
        this.tinggi = tinggi;
    }

    public String getHasil() {
        return hasil;
    }

    public void setHasil(String hasil) {
        this.hasil = hasil;
    }
}
