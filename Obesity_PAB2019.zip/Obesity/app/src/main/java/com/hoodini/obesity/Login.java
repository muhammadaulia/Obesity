package com.hoodini.obesity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.net.InetAddress;

public class Login extends AppCompatActivity {
    public EditText loginmail, loginpass;
    Button buttonlogin, buttondaftar;
    FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        FirebaseApp.initializeApp(this);
        //authentication account
        firebaseAuth = FirebaseAuth.getInstance();
        loginmail = findViewById(R.id.isiEmail);
        loginpass = findViewById(R.id.isiPass);
        buttonlogin = findViewById(R.id.btnlogin);
        buttondaftar = findViewById(R.id.btnregis);

        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
//                    Toast.makeText(Login.this, "User logged in ", Toast.LENGTH_SHORT).show();
                    Intent I = new Intent(Login.this, MainActivity.class);
                    startActivity(I);
                } else {
//                    Toast.makeText(Login.this, "Login to continue", Toast.LENGTH_SHORT).show();
                }
            }
        };
        buttonlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                        connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED && isInternetAvailable()) {
                    //login code
                    final String loginEmail = loginmail.getText().toString();
                    String loginPassword = loginpass.getText().toString();
                    if (loginEmail.isEmpty()) {
                        loginmail.setError("Masukkan Email!");
                        loginmail.requestFocus();
                    } else if (loginPassword.isEmpty()) {
                        loginpass.setError("Masukkan Password!");
                        loginpass.requestFocus();
                    } else {
                        firebaseAuth.signInWithEmailAndPassword(loginEmail, loginPassword).addOnCompleteListener(Login.this, new OnCompleteListener() {
                            @Override
                            public void onComplete(@NonNull Task task) {
                                if (!task.isSuccessful()) {
                                    Toast.makeText(Login.this, "Email atau Password Tidak Cocok", Toast.LENGTH_SHORT).show();
                                } else {
                                    startActivity(new Intent(Login.this, MainActivity.class));
                                }
                            }
                        });
                    }
                } else {
                    Snackbar.make(view, "Koneksi Tidak Tersedia", Snackbar.LENGTH_LONG).show();
//                    Toast.makeText(Login.this, "Koneksi Tidak Teresdia", Toast.LENGTH_SHORT).show();
                }

            }

        });
        buttondaftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setButtondaftar(view);
            }
        });


    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
        builder.setTitle(R.string.app_name);
//        builder.setIcon(R.drawable.icontube2);
        builder.setMessage("Do you want to exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    //    private boolean isNetworkConnected() {
//        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//        return cm.getActiveNetwork() != null && cm.getActiveNetworkInfo().isConnected();
//    }
    public boolean isInternetAvailable() {
        try {
            InetAddress ipAddr = InetAddress.getByName("8.8.8.8");
            //You can replace it with your name
            return !ipAddr.equals("");

        } catch (Exception e) {
            return false;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        firebaseAuth.addAuthStateListener(authStateListener);
    }

    public void setButtondaftar(View view) {
        startActivity(new Intent(getApplicationContext(), Register.class));
    }
}
