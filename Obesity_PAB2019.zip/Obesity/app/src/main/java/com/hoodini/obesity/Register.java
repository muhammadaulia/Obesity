package com.hoodini.obesity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.net.InetAddress;
import java.util.Objects;

public class Register extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private EditText Nama;
    public EditText Email;
    private EditText Nomor;
    public EditText Password;
    public EditText UlangPass;
    public RadioGroup jKel;
    public RadioButton jenisKelaminUser;
    FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;
    Button buttonregis;
    private DatabaseReference database;
    private FirebaseUser firebaseuser;
    String usermail, userpass, userrepass, usernama, usernomor, gender;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //create account auth
        firebaseAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance().getReference();
        jKel = findViewById(R.id.radioGroup);
        Email = findViewById(R.id.regisemail);
        Password = findViewById(R.id.regispass);
        UlangPass = findViewById((R.id.regisrepass));
        //create account database
        Nama = findViewById(R.id.regisnama);
        Nomor = findViewById(R.id.regishape);
        jenisKelaminUser = findViewById(jKel.getCheckedRadioButtonId());

        jKel.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                jenisKelaminUser = jKel.findViewById(i);
                switch (i) {
                    case R.id.radio_pria:
                        gender = jenisKelaminUser.getText().toString();
                    case R.id.radio_wanita:
                        gender = jenisKelaminUser.getText().toString();
                        break;
                    default:
                }
            }
        });

        //onclick button
        buttonregis = findViewById(R.id.btn_regis);
        buttonregis.setOnClickListener(new View.OnClickListener() { //Register new User
            @Override
            public void onClick(View view) {
                usermail = Email.getText().toString();
                userpass = Password.getText().toString();
                userrepass = UlangPass.getText().toString();
                usernama = Nama.getText().toString();
                usernomor = Nomor.getText().toString();
                gender = jenisKelaminUser.getText().toString();

                System.out.println("Jkel "+gender);

                if (usermail.isEmpty()) {
                    Email.setError("Masukkan Email Kamu");
                    Email.requestFocus();
                } else if (userpass.isEmpty()) {
                    Password.setError("Masukkan Password Kamu");
                    Password.requestFocus();
                } else if (!userrepass.equals(userpass)) {
                    UlangPass.setError("Password Kamu Tidak Cocok");
                    UlangPass.requestFocus();
                } else if (usernama.isEmpty()) {
                    Nama.setError("Masukkan Nama Lengkap Kamu");
                    Nama.requestFocus();
                }else if (gender.isEmpty()){
                    jenisKelaminUser.setError("Pilih Jenis Kelamin Kamu");
                    jenisKelaminUser.requestFocus();
                }
                else if (usernomor.isEmpty()) {
                    Nomor.setError("Masukkan Tempat Lahir Kamu");
                    Nomor.requestFocus();
                } else {
                    ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                    if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                            connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED && isInternetAvailable()) {
                        firebaseAuth.createUserWithEmailAndPassword(usermail, userpass).addOnCompleteListener(Register.this,
                                new OnCompleteListener() {
                                    @Override
                                    public void onComplete(@NonNull Task task) {
                                        if (!task.isSuccessful()) {
                                            Toast.makeText(Register.this.getApplicationContext(),
                                                    "SignUp unsuccessful: " + Objects.requireNonNull(task.getException()).getMessage(),
                                                    Toast.LENGTH_SHORT).show();

                                        } else {
                                            firebaseuser = firebaseAuth.getCurrentUser();
                                            submitData(new User(usermail, usernama, usernomor, userpass, userrepass, gender));
                                            startActivity(new Intent(Register.this, Login.class));
                                        }
                                    }
                                });
                    }
                }
            }
        });
        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    Toast.makeText(Register.this, "User logged in ", Toast.LENGTH_SHORT).show();
                    Intent toMainAct = new Intent(Register.this, MainActivity.class);
                    startActivity(toMainAct);
                }
            }
        };
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public boolean isInternetAvailable() {
        try {
            InetAddress ipAddr = InetAddress.getByName("8.8.8.8");
            //You can replace it with your name
            return !ipAddr.equals("");

        } catch (Exception e) {
            return false;
        }
    }
    public void submitData(User user) {
        database.child("User/" + firebaseuser.getUid()).setValue(user).addOnSuccessListener(this, new OnSuccessListener<Void>() {

            @Override
            public void onSuccess(Void aVoid) {
                Email.setText("");
                Password.setText("");
                Nama.setText("");
                UlangPass.setText("");
                Nomor.setText("");
                jenisKelaminUser.setText("");
                Snackbar.make(findViewById(R.id.btn_regis), "Data berhasil ditambahkan", Snackbar.LENGTH_LONG).show();
            }
        });
    }
}