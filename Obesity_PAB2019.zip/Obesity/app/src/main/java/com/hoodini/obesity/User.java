package com.hoodini.obesity;

import androidx.annotation.NonNull;

public class User {
    private String Nama;
    private String Email;
    private String Nomor;
    private String Password;
    private String UlangPass;
    private String Jkel;

    User(String em, String nm, String nmr, String pw, String up, String jk) {
        Email = em;
        Nama = nm;
        Nomor = nmr;
        Password = pw;
        UlangPass = up;
        Jkel = jk;

    }

    public String getJkel() {
        return Jkel;
    }

    public void setJkel(String jkel) {
        Jkel = jkel;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getNomor() {
        return Nomor;
    }

    public void setNomor(String nomor) {
        Nomor = nomor;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getUlangPass() {
        return UlangPass;
    }

    public void setUlangPass(String ulangPass) {
        UlangPass = ulangPass;
    }

    @NonNull
    @Override
    public String toString() {
        return " " + Nama + "\n" +
                " " + Email + "\n" +
                " " + Nomor + "\n" +
                " " + Password + "\n" +
                " " + UlangPass +"\n"+
                " " + Jkel;
    }
}
