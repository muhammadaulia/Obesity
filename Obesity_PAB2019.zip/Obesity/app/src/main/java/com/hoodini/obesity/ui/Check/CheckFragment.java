package com.hoodini.obesity.ui.Check;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.hoodini.obesity.History;
import com.hoodini.obesity.ListDataDiri;
import com.hoodini.obesity.R;
import com.hoodini.obesity.DataPengguna;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class CheckFragment extends Fragment {
    private SeekBar bar, barTB;
    private TextView textBar, textTB;
    private String gender;
    private DatabaseReference database;
    private ArrayList<ListDataDiri> listDataDiris;
    private ArrayList<DataPengguna> arrayList;
    private int seekTB = 160, seekBB = 10;
    private double IMT;
    FirebaseUser firebaseUser;
    private ImageView imageView;
    public TextView textView;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_check,
                container, false);
        final String[] Kesimpulan = new String[1];
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        bar = view.findViewById(R.id.seekBB);
        barTB = view.findViewById(R.id.seekTB);
        bar.setMax(150);
        bar.setProgress(10);
        barTB.setMax(200);
        barTB.setProgress(160);
        imageView = view.findViewById(R.id.image_gender);
        textTB = view.findViewById(R.id.textSeekBarTB);
        textBar = view.findViewById(R.id.textSeekBar);
        barTB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                RelativeLayout.LayoutParams p = new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT);
                p.addRule(RelativeLayout.ALIGN_BOTTOM, seekBar.getId());
                p.setMargins(852, 0, 0, 400 + (i * 5));
                textTB.setLayoutParams(p);
                String a = Integer.toString(i);
                textTB.setText(a + " CM");
                seekTB = seekBar.getProgress();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                RelativeLayout.LayoutParams p = new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT);
                p.addRule(RelativeLayout.ABOVE, seekBar.getId());
                p.setMargins(progress * 6, 0, 0, 0);
                textBar.setLayoutParams(p);
                String a = Integer.toString(progress);
                textBar.setText(a + " KG");
                seekBB = bar.getProgress();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });


//        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(imageView.getLayoutParams().width+bar.getProgress(),
//                imageView.getLayoutParams().height+barTB.getProgress());

        final FloatingActionButton fab = view.findViewById(R.id.floatingActionButton);
        database = FirebaseDatabase.getInstance().getReference();
        final Query query = database.child("User/"+firebaseUser.getUid()+"/jkel");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                gender = dataSnapshot.getValue().toString();
                if (gender.equals("Laki- Laki")){
                    imageView.setImageResource(R.drawable.cowok);
                }else if(gender.equals("Perempuan")){
                    imageView.setImageResource(R.drawable.cewek);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Haha "+gender);
                Date c = Calendar.getInstance().getTime();
                System.out.println("Current time => " + c);
                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                final String formattedDate = df.format(c);
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                if (gender.equals("Laki- Laki")) {
                    final Query query = database.child("tabelLaki");
                    query.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            listDataDiris = new ArrayList<>();
                            for (DataSnapshot ds : dataSnapshot.getChildren()) {
                                ListDataDiri listDataDiri = ds.getValue(ListDataDiri.class);
                                listDataDiris.add(listDataDiri);
                            }
                            String berat = String.valueOf(seekBB);
                            String tBadan = String.valueOf(seekTB);
                            int index = 0;
                            for (int i = 0; i < listDataDiris.size(); i++) {
                                if (listDataDiris.get(index).getTb().toString().equals(tBadan) &&
                                        listDataDiris.get(index).getBb().toString().equals(berat)) {
                                    IMT = listDataDiris.get(index).getKes();
                                    System.out.println(index + " " + listDataDiris.get(index).getKet());
                                } else {
                                    String tbPrse = String.valueOf(seekTB);
                                    String bbPrse = String.valueOf(seekBB);
                                    double tbhsl = Double.parseDouble(tbPrse);
                                    double bbhsl = Double.parseDouble(bbPrse);
                                    IMT = bbhsl / ((tbhsl/100)*(tbhsl/100));
                                }
                                if (IMT < 18.5) {
                                    Kesimpulan[0] = "Kurus (underweight)";
                                } else if (IMT >= 18.5 && IMT < 25.0) {
                                    Kesimpulan[0] = "Normal (ideal)";
                                } else if (IMT >= 25.0 && IMT < 30.0) {
                                    Kesimpulan[0] = "Kegemukan (overweight)";
                                } else if (IMT >= 30.0 && IMT < 35.0) {
                                    Kesimpulan[0] = "Obesitas Tingkat 1";
                                } else if (IMT >= 35.0 && IMT < 40.0) {
                                    Kesimpulan[0] = "Obesitas Tingkat 2";
                                } else if (IMT >= 40.0) {
                                    Kesimpulan[0] = "Obesitas Tingkat 3";
                                }
                                textView.setText(Kesimpulan[0]);
                                index++;
                            }
                            submitData(new History(formattedDate, Kesimpulan[0], seekTB, seekBB));

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Log.e("The read failed: ", databaseError.getMessage());
                        }
                    });
                } else if (gender.equals("Perempuan")) {
                    final Query query = database.child("tabelPerempuan");
                    query.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            listDataDiris = new ArrayList<>();
                            for (DataSnapshot ds : dataSnapshot.getChildren()) {
                                ListDataDiri listDataDiri = ds.getValue(ListDataDiri.class);
                                listDataDiris.add(listDataDiri);
                            }
                            int index = 0;
                            String berat = String.valueOf(seekBB);
                            String tBadan = String.valueOf(seekTB);
                            for (int i = 0; i < listDataDiris.size(); i++) {
                                if (listDataDiris.get(index).getTb().toString().equals(tBadan) &&
                                        listDataDiris.get(index).getBb().toString().equals(berat)) {
                                    IMT = listDataDiris.get(index).getKes();
                                    System.out.println(index + " " + listDataDiris.get(index).getKet());
                                } else {
                                    String tbPrse = String.valueOf(seekTB);
                                    String bbPrse = String.valueOf(seekBB);
                                    double tbhsl = Double.parseDouble(tbPrse);
                                    double bbhsl = Double.parseDouble(bbPrse);
                                    IMT = bbhsl / ((tbhsl/100)*(tbhsl/100));
                                }
                                if (IMT < 17) {
                                    Kesimpulan[0] = "Kurus (underweight)";
                                } else if (IMT >= 17.0 && IMT < 23.0) {
                                    Kesimpulan[0] = "Normal (ideal)";
                                } else if (IMT >= 23.0 && IMT < 27.0) {
                                    Kesimpulan[0] = "Kegemukan (overweight)";
                                } else if (IMT >= 27.0 && IMT < 32.0) {
                                    Kesimpulan[0] = "Obesitas Tingkat 1";
                                } else if (IMT >= 32.0 && IMT < 37.0) {
                                    Kesimpulan[0] = "Obesitas Tingkat 2";
                                } else if (IMT >= 37.0) {
                                    Kesimpulan[0] = "Obesitas Tingkat 3";
                                }
                                textView.setText(Kesimpulan[0]);
                                index++;
                            }
                            submitData(new History(formattedDate, Kesimpulan[0], seekTB, seekBB));
                        }

                        //
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Log.e("The read failed: ", databaseError.getMessage());
                        }
                    });
                }
                View mView = getLayoutInflater().inflate(R.layout.hasil_cek_resiko_dialog, null);
                textView = mView.findViewById(R.id.hasilResiko);
                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();
            }

        });

        return view;
    }
    public void submitData(History history) {
        database.child("History/"+firebaseUser.getUid()).push().setValue(history).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(getContext(),"Data berhasil ditambahkan",Toast.LENGTH_SHORT);
            }
        });
    }

}
