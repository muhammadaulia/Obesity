package com.hoodini.obesity.ui.History;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.hoodini.obesity.AdapterHistoryView;
import com.hoodini.obesity.ListHistory;
import com.hoodini.obesity.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class HistoryFragment extends Fragment{
    DatabaseReference database;
    FirebaseUser firebaseUser;
    ArrayList<ListHistory> arrayList;
    //    List<String> list;
    ArrayList<ListHistory> list;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    ArrayAdapter<String> arrayAdapter;
    ArrayAdapter<String> sort_arrayAdapter;
    Context context;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_history,
                container, false);

        if (isAdded()) {
            context = getContext();
        }

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
//        list = new ArrayList<String>();
//        list.clear();
        recyclerView = view.findViewById(R.id.rv_main);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
//        final ListView history = (ListView) view.findViewById(R.id.history_list);
        database = FirebaseDatabase.getInstance().getReference();
        final Query query = database.child("History/"+firebaseUser.getUid());
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                arrayList = new ArrayList<>();
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                    ListHistory listHistory = dataSnapshot1.getValue(ListHistory.class);
                    listHistory.setKey(dataSnapshot1.getKey());
                    arrayList.add(listHistory);
                }
//                for (int i =0;i<arrayList.size();i++){
//                    String berat = String.valueOf(arrayList.get(i).getBerat());
//                    String tinggi = String.valueOf(arrayList.get(i).getTinggi());
//                    list.add(arrayList.get(i).getDate());
//                    list.add(berat);
//                    list.add(tinggi);
//                    list.add(arrayList.get(i).getHasil());
//                }
//                System.out.println(list);
//                arrayAdapter = new ArrayAdapter<>(context,android.R.layout.simple_list_item_1,list);
//                history.setAdapter(arrayAdapter);
                Collections.reverse(arrayList);
                adapter = new AdapterHistoryView(arrayList, context);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                System.out.println(databaseError.getDetails() + " " + databaseError.getMessage());
            }
        });
        return view;
    }

}